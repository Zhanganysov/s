package com.justDoIT;

public class apple implements Isound{
    int cost = 20;
    int reg = 100;

    person Personbek=new person();
    public void eatSound(){
        System.out.println("Eating... +");
    }

    @Override
    public void OchenBolno() {
    }
    @Override
    public void NeOcenBolno() {
    }

    void buyApple(){
        if (Personbek.money > cost) {
            Personbek.money -= cost;
            Personbek.health += reg;
        }
    }
}
