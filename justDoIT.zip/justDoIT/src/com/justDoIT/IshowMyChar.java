package com.justDoIT;

public interface IshowMyChar {
    void showChar(int i, int b);
}
