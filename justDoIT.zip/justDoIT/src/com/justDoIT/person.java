package com.justDoIT;

import java.util.Scanner;

public class person implements Isound,IconvertMyInt{
    String name;
    int money=1000;
    int health=500;
    int damage=10;
    int armor=0;

    public person(String name) {
        this.name=name;
    }
    public person(){}
    // commands
    void showChar(){
        System.out.println("================"+name+"==================");
        System.out.println("Money: "+convertMoney(money)+ " || " + "Health: "+convertHP(health)+ " || " + "Armor: "+armor);
        System.out.println("");

    }
    void showCommands(){
        System.out.println("Available commands: stats, foodshop, arena");
    }

    @Override
    public void eatSound() {
        System.out.println("Eating..");
    }

    @Override
    public void OchenBolno() {
        System.out.println("Nice hit, sir!");
    }

    @Override
    public void NeOcenBolno() {
        System.out.println("ahaha, bad hit!");
    }

    @Override
    public String convertMoney(int i) {
        return i+"$";
    }
    @Override
    public String convertHP(int i) {
        return i+"HP";
    }
}
