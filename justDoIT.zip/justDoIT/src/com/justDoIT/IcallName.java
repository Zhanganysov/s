package com.justDoIT;

public interface IcallName {
    void callMyName();
}
