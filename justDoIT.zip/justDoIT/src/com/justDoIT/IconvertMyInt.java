package com.justDoIT;

public interface IconvertMyInt {
    String convertMoney(int i);
    String convertHP(int i);
}
