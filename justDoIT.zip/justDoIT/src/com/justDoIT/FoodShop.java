package com.justDoIT;

public class FoodShop implements Isound,IconvertMyInt{

        apple apple = new apple();
        pie pie = new pie();

    void showMeCost(String fType, String fCost, String fReg){
        System.out.println(fType + " cost:"+fCost+ " regeneration:"+ fReg);
    }

    void showFoodshop() {
        System.out.println("In our menu: ");
        showMeCost("apple:", convertMoney(apple.cost), convertHP(apple.reg));      //apple
        showMeCost("pie:  ", convertMoney(pie.cost), convertHP(pie.reg));            //pie
    }

    @Override
    public void eatSound() {
        System.out.println("Eating..");
    }

    @Override
    public void OchenBolno() {
    }

    @Override
    public void NeOcenBolno() {
    }

    @Override
    public String convertMoney(int i) {
        String X= i+"$";        //for money
        return X;
    }
    @Override
    public String convertHP(int i) {
        String X= i+"HP";        //for health
        return X;
    }
}
