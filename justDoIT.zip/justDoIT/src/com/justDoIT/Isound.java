package com.justDoIT;

public interface Isound {
    void eatSound();
    void OchenBolno();
    void NeOcenBolno();
}
