package com.justDoIT;

import java.security.spec.RSAOtherPrimeInfo;
import java.util.Scanner;

public class Main {

    public static void main(String[] args) {

        person Pers1   = new person("Sam");
        FoodShop Food1 = new FoodShop();
        enemy1lvl Enym = new enemy1lvl();
        apple apple    = new apple();
        pie pie        = new pie();

        boolean a=true;

        while(a) {
            Pers1.showCommands();
            try {
                Scanner in = new Scanner(System.in);
                String num = in.next();
                switch (num) {
                    case "stats" -> Pers1.showChar();
                    case "foodshop" -> {
                        Food1.showFoodshop();
                        Scanner xin = new Scanner(System.in);
                        String Xum = in.next();
                        if (Xum.equals("apple")) {
                            apple.buyApple();
                            Pers1.money -= apple.cost;
                            Pers1.health += apple.reg;
                            Pers1.eatSound();
                            Pers1.showChar();
                        } else if (Xum.equals("pie")) {
                            pie.buyPie();
                            Pers1.money -= pie.cost;
                            Pers1.health += pie.reg;
                            Pers1.eatSound();
                            Pers1.showChar();
                        }
                    }
                    case "arena" -> {
                        Enym.showEnym1();

                        do{Enym.winEnym1();
                        }
                        while (a);
                            Pers1.showChar();
                    }
                    default -> throw new IllegalStateException("Unexpected value: " + num);
                }

            } catch (Exception e) {
                System.out.println("Invalid command");
            }
        }
    }
}






