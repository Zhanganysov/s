package com.justDoIT;

public interface IshowMyArmor {
    void showArm(int i, int b);
}
