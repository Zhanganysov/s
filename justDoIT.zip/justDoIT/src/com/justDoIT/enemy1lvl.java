package com.justDoIT;

import java.util.Scanner;

public class enemy1lvl implements IcallName,IshowMyChar,IshowMyArmor {
    person Pers = new person();
    int damageEnym1 = 40;
    int healthEnym1 = 100;

    int damageEnym2 = 60;
    int healthEnym2 = 155;

    int damageEnym3 = 70;
    int healthEnym3 = 220;

    
    int RandNum1(int a, int b){
        return a + (int) (Math.random() * b);
    }
    @Override
    public void callMyName() {
        System.out.println("Enemy!...");
    }

    @Override
    public void showChar(int i, int b) {
        System.out.println("Health:" + i);
        System.out.println("Damage:" + b);
        System.out.println("");
    }

    void showEnym1() {
        callMyName();
        System.out.println("Maxim!");
        showChar(healthEnym1, damageEnym1);
    }

    void showEnym2() {
        callMyName();
        System.out.println("Maxim!");
        showChar(damageEnym2, healthEnym2);
    }

    void showEnym3() {
        callMyName();
        System.out.println("Maxim!");
        showChar(damageEnym3, healthEnym3);
    }
    void getMoney(int i){
        Pers.money+=i;
        System.out.println("You earned:"+i+"$");
    }

    void winEnym1() {
        Scanner in = new Scanner(System.in);
        String num = in.next();
        if ("attack".equals(num)) {
            {
                int x = Pers.damage * (10 / RandNum1(3, 5));
                if(x>=20) {
                Pers.OchenBolno();
                }
                else { Pers.NeOcenBolno();
                }
                healthEnym1 -= x;
                System.out.println("- " + x + "Hp");
                System.out.println("Maxim Health:" + healthEnym1);
                Pers.health = Pers.health - damageEnym1;
                System.out.println("Your Health:" + Pers.health);
            }
            if (healthEnym1 <= 0) {
                healthEnym1 = 0;
                System.out.println("You win");
                getMoney(40);
                Pers.showChar();
            } else if (Pers.health <= 0) {
                System.out.println("Game over");
            }
        }
    }

    @Override
    public void showArm(int i, int b) {
        System.out.println("Armor"+b+"lvl");
    }
}