package com.justDoIT;

public class pie implements Isound{
    int cost=10;
    int reg = 40;
    person person = new person();
    public void eatSound(){
        System.out.println("Eating... +");
    }

    @Override
    public void OchenBolno() {
    }

    @Override
    public void NeOcenBolno() {
    }

    void buyPie(){
        if (person.money > cost) {
            person.money -= cost;
            person.health += reg;
        }
    }
}
